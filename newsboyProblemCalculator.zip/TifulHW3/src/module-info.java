module NewsboyProblemCalculator {
    requires javafx.fxml;
    requires javafx.controls;
    requires junit;

    opens sample;
}
